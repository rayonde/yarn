"""
dummy.py - This module defines a dummy class.
"""

class Dummy(object):
    """
    This is a dummy class to keep track of
    what have you.

    Fields: indeterminate
    """

    def __init__(self):
        super().__init__()
